# MusicPlay 后端项目

## 项目简介

MusicPlay 是一个基于 Spring Boot 2.x + MySQL + MyBatis 的音乐播放器后端服务，提供完整的用户认证、歌曲管理、歌单管理和播放记录功能。

## 技术栈

- **语言**: Java 8
- **框架**: Spring Boot 2.7.18
- **数据库**: MySQL 8.x
- **ORM**: MyBatis 2.3.3
- **连接池**: Druid 1.2.20
- **安全**: Spring Security + JWT (JJWT 0.11.5)
- **工具**: Lombok, FastJSON 2.0.42, Apache Commons Lang3
- **日志**: Log4j2

## 项目结构

```
backEnd/
├── src/main/
│   ├── java/com/musicplay/
│   │   ├── MusicPlayApplication.java          # 主启动类
│   │   ├── common/                             # 公共模块
│   │   │   ├── exception/                      # 异常处理
│   │   │   │   ├── BizException.java
│   │   │   │   └── GlobalExceptionHandler.java
│   │   │   └── result/                         # 统一响应
│   │   │       ├── Result.java
│   │   │       └── PageResult.java
│   │   ├── controller/                         # 控制器层
│   │   │   ├── AuthController.java
│   │   │   ├── TrackController.java
│   │   │   ├── FolderController.java
│   │   │   ├── PlaylistController.java
│   │   │   ├── PlaybackController.java
│   │   │   └── HealthController.java
│   │   ├── dao/                                # 数据访问层 (Mapper)
│   │   │   ├── UserMapper.java
│   │   │   ├── TrackMapper.java
│   │   │   ├── ArtistMapper.java
│   │   │   ├── AlbumMapper.java
│   │   │   ├── FolderMapper.java
│   │   │   ├── PlaylistMapper.java
│   │   │   ├── PlaylistTrackMapper.java
│   │   │   └── PlaybackRecordMapper.java
│   │   ├── domain/                             # 领域模型（实体类）
│   │   │   ├── User.java
│   │   │   ├── Track.java
│   │   │   ├── Artist.java
│   │   │   ├── Album.java
│   │   │   ├── Folder.java
│   │   │   ├── Playlist.java
│   │   │   ├── PlaylistTrack.java
│   │   │   └── PlaybackRecord.java
│   │   ├── dto/                                # 数据传输对象（请求）
│   │   │   ├── UserLoginRequest.java
│   │   │   ├── UserLoginResponse.java
│   │   │   ├── PlaylistCreateRequest.java
│   │   │   ├── PlaylistUpdateRequest.java
│   │   │   ├── AddTrackToPlaylistRequest.java
│   │   │   └── PlaybackRecordRequest.java
│   │   ├── vo/                                 # 视图对象（响应）
│   │   │   ├── UserVO.java
│   │   │   ├── TrackVO.java
│   │   │   ├── PlaylistVO.java
│   │   │   ├── FolderVO.java
│   │   │   └── PlaybackRecordVO.java
│   │   ├── security/                           # 安全模块
│   │   │   ├── SecurityConfig.java
│   │   │   ├── JwtTokenService.java
│   │   │   ├── JwtAuthenticationFilter.java
│   │   │   ├── MusicPlayPrincipal.java
│   │   │   └── SecurityUtil.java
│   │   └── service/                            # 业务逻辑层
│   │       ├── UserService.java
│   │       ├── TrackService.java
│   │       ├── FolderService.java
│   │       ├── PlaylistService.java
│   │       ├── PlaybackService.java
│   │       └── impl/                           # Service 实现
│   │           ├── UserServiceImpl.java
│   │           ├── TrackServiceImpl.java
│   │           ├── FolderServiceImpl.java
│   │           ├── PlaylistServiceImpl.java
│   │           └── PlaybackServiceImpl.java
│   └── resources/
│       ├── application.yml                     # 应用配置
│       ├── log4j2.xml                          # 日志配置
│       ├── schema.sql                          # 数据库建表脚本
│       └── mapper/                             # MyBatis XML 映射文件
│           ├── UserMapper.xml
│           ├── TrackMapper.xml
│           ├── ArtistMapper.xml
│           ├── AlbumMapper.xml
│           ├── FolderMapper.xml
│           ├── PlaylistMapper.xml
│           ├── PlaylistTrackMapper.xml
│           └── PlaybackRecordMapper.xml
├── pom.xml                                     # Maven 配置文件
└── BACKEND_README.md                           # 本文档
```

## 快速开始

### 1. 环境要求

- JDK 8 或更高版本
- Maven 3.6+
- MySQL 8.x

### 2. 数据库初始化

```sql
-- 执行 schema.sql 初始化数据库和表结构
source backEnd/src/main/resources/schema.sql
```

或者手动执行：

```bash
mysql -u root -p < backEnd/src/main/resources/schema.sql
```

### 3. 修改配置

编辑 `src/main/resources/application.yml`，修改数据库连接信息：

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/musicplay?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=Asia/Shanghai
    username: root
    password: your_password
```

### 4. 启动应用

#### 使用 Maven Wrapper（推荐）

```bash
cd backEnd
.\mvnw.cmd spring-boot:run
```

#### 使用 Maven

```bash
cd backEnd
mvn clean spring-boot:run
```

#### 打包后运行

```bash
cd backEnd
mvn clean package
java -jar target/musicplay-backend-0.1.0.jar
```

### 5. 验证启动

访问健康检查接口：

```bash
curl http://localhost:8080/health
```

返回：
```json
{
  "code": 0,
  "message": "success",
  "data": "OK"
}
```

## API 文档

### 认证接口

#### 登录

```bash
POST /api/auth/login
Content-Type: application/json

{
  "username": "testuser",
  "password": "123456"
}
```

响应：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "userId": 1,
    "username": "testuser",
    "nickname": "测试用户"
  }
}
```

#### 获取当前用户信息

```bash
GET /api/auth/me
Authorization: Bearer <token>
```

### 歌曲接口

#### 查询歌曲列表

```bash
GET /api/tracks?keyword=周杰伦&current=1&size=20
Authorization: Bearer <token>
```

#### 获取歌曲详情

```bash
GET /api/tracks/{id}
Authorization: Bearer <token>
```

### 文件夹接口

#### 获取文件夹列表

```bash
GET /api/folders
Authorization: Bearer <token>
```

#### 获取文件夹下的歌曲

```bash
GET /api/folders/{id}/tracks
Authorization: Bearer <token>
```

### 歌单接口

#### 获取我的歌单

```bash
GET /api/playlists
Authorization: Bearer <token>
```

#### 创建歌单

```bash
POST /api/playlists
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "我的歌单",
  "description": "描述信息"
}
```

#### 更新歌单

```bash
PUT /api/playlists/{id}
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "新名称",
  "description": "新描述"
}
```

#### 删除歌单

```bash
DELETE /api/playlists/{id}
Authorization: Bearer <token>
```

#### 获取歌单中的歌曲

```bash
GET /api/playlists/{id}/tracks
Authorization: Bearer <token>
```

#### 添加歌曲到歌单

```bash
POST /api/playlists/{id}/tracks
Authorization: Bearer <token>
Content-Type: application/json

{
  "trackId": 1,
  "orderIndex": 1
}
```

#### 从歌单中移除歌曲

```bash
DELETE /api/playlists/{id}/tracks/{trackId}
Authorization: Bearer <token>
```

### 播放记录接口

#### 记录播放

```bash
POST /api/playback/records
Authorization: Bearer <token>
Content-Type: application/json

{
  "trackId": 1,
  "position": 120,
  "duration": 60
}
```

#### 获取最近播放

```bash
GET /api/playback/recent?limit=20
Authorization: Bearer <token>
```

## 测试数据

项目初始化时包含以下测试数据：

### 用户
- 用户名: `testuser`
- 密码: `123456`
- 昵称: `测试用户`

### 歌曲
- 爱在西元前 (周杰伦)
- 七里香 (周杰伦)

### 文件夹
- 流行音乐
- 经典老歌

### 歌单
- 我喜欢的歌（包含2首测试歌曲）

## 安全说明

### JWT 配置

生产环境必须修改 `application.yml` 中的 JWT 密钥：

```yaml
musicplay:
  jwt:
    secret: "YOUR_SECURE_RANDOM_KEY_MIN_32_CHARS"
    expireSeconds: 604800  # 7天
```

### 数据库安全

- 不要在生产环境使用默认密码
- 建议使用环境变量管理数据库密码
- 定期备份数据库

## 开发指南

### 添加新接口

1. 在 `controller` 包下创建 Controller 类
2. 在 `service` 包下创建 Service 接口
3. 在 `service.impl` 包下实现 Service
4. 如需数据库操作，在 `dao` 包下创建 Mapper 接口
5. 在 `resources/mapper` 下创建对应的 XML 映射文件

### 异常处理

使用 `BizException` 抛出业务异常：

```java
throw new BizException("业务错误信息");
```

### 获取当前用户

```java
Long userId = SecurityUtil.getCurrentUserId();
String username = SecurityUtil.getCurrentUsername();
```

## 常见问题

### 1. 连接数据库失败

检查 `application.yml` 中的数据库配置是否正确，确保 MySQL 服务已启动。

### 2. Maven 依赖下载失败

使用阿里云镜像（已在 pom.xml 中配置），或检查网络连接。

### 3. JWT 验证失败

检查 `Authorization` 请求头格式：`Bearer <token>`（注意中间有空格）。

### 4. MyBatis 映射文件找不到

确保 `application.yml` 中配置了正确的 mapper 位置：

```yaml
mybatis:
  mapper-locations: classpath:mapper/*.xml
```

## 许可证

[项目许可证文件](../LICENSE)
