-- =============================================
-- MusicPlay Database Schema
-- MySQL 8.x
-- =============================================

-- 创建数据库（如果不存在）
CREATE DATABASE IF NOT EXISTS musicplay DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE musicplay;

-- =============================================
-- 1. 用户表
-- =============================================
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` VARCHAR(50) NOT NULL COMMENT '用户名',
  `password_hash` VARCHAR(255) NOT NULL COMMENT '密码哈希',
  `nickname` VARCHAR(50) DEFAULT NULL COMMENT '昵称',
  `status` TINYINT NOT NULL DEFAULT 0 COMMENT '状态：0-正常，1-禁用',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- =============================================
-- 2. 歌手表
-- =============================================
DROP TABLE IF EXISTS `artist`;
CREATE TABLE `artist` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '歌手ID',
  `name` VARCHAR(100) NOT NULL COMMENT '歌手名称',
  `alias` VARCHAR(255) DEFAULT NULL COMMENT '别名',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌手表';

-- =============================================
-- 3. 专辑表
-- =============================================
DROP TABLE IF EXISTS `album`;
CREATE TABLE `album` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '专辑ID',
  `name` VARCHAR(100) NOT NULL COMMENT '专辑名称',
  `artist_id` BIGINT DEFAULT NULL COMMENT '歌手ID',
  `cover_url` VARCHAR(500) DEFAULT NULL COMMENT '封面URL',
  `year` INT DEFAULT NULL COMMENT '发行年份',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_artist_id` (`artist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='专辑表';

-- =============================================
-- 4. 歌曲表
-- =============================================
DROP TABLE IF EXISTS `track`;
CREATE TABLE `track` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '歌曲ID',
  `title` VARCHAR(255) NOT NULL COMMENT '歌曲标题',
  `artist_id` BIGINT DEFAULT NULL COMMENT '歌手ID',
  `album_id` BIGINT DEFAULT NULL COMMENT '专辑ID',
  `duration` INT DEFAULT NULL COMMENT '时长（秒）',
  `bitrate` INT DEFAULT NULL COMMENT '比特率（kbps）',
  `file_path` VARCHAR(500) DEFAULT NULL COMMENT '文件路径',
  `audio_url` VARCHAR(500) DEFAULT NULL COMMENT '音频URL',
  `cover_url` VARCHAR(500) DEFAULT NULL COMMENT '封面图URL',
  `source_type` VARCHAR(20) NOT NULL DEFAULT 'LOCAL' COMMENT '来源类型：LOCAL-本地，REMOTE-远程',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_title` (`title`),
  KEY `idx_artist_id` (`artist_id`),
  KEY `idx_album_id` (`album_id`),
  KEY `idx_source_type` (`source_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌曲表';

-- =============================================
-- 5. 文件夹表
-- =============================================
DROP TABLE IF EXISTS `folder`;
CREATE TABLE `folder` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '文件夹ID',
  `name` VARCHAR(255) NOT NULL COMMENT '文件夹名称',
  `path` VARCHAR(500) NOT NULL COMMENT '文件夹路径',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='文件夹表';

-- =============================================
-- 6. 歌曲-文件夹关联表
-- =============================================
DROP TABLE IF EXISTS `track_folder`;
CREATE TABLE `track_folder` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '关联ID',
  `track_id` BIGINT NOT NULL COMMENT '歌曲ID',
  `folder_id` BIGINT NOT NULL COMMENT '文件夹ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_track_folder` (`track_id`, `folder_id`),
  KEY `idx_folder_id` (`folder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌曲-文件夹关联表';

-- =============================================
-- 7. 歌单表
-- =============================================
DROP TABLE IF EXISTS `playlist`;
CREATE TABLE `playlist` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '歌单ID',
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `name` VARCHAR(100) NOT NULL COMMENT '歌单名称',
  `description` VARCHAR(500) DEFAULT NULL COMMENT '歌单描述',
  `cover_url` VARCHAR(500) DEFAULT NULL COMMENT '封面URL',
  `type` VARCHAR(50) NOT NULL DEFAULT 'USER' COMMENT '歌单类型：USER-用户创建，SMART_RECENT-最近播放',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌单表';

-- =============================================
-- 8. 歌单-歌曲关联表
-- =============================================
DROP TABLE IF EXISTS `playlist_track`;
CREATE TABLE `playlist_track` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '关联ID',
  `playlist_id` BIGINT NOT NULL COMMENT '歌单ID',
  `track_id` BIGINT NOT NULL COMMENT '歌曲ID',
  `order_index` INT NOT NULL DEFAULT 0 COMMENT '排序索引',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_playlist_id` (`playlist_id`),
  KEY `idx_playlist_order` (`playlist_id`, `order_index`),
  KEY `idx_track_id` (`track_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌单-歌曲关联表';

-- =============================================
-- 9. 播放记录表
-- =============================================
DROP TABLE IF EXISTS `playback_record`;
CREATE TABLE `playback_record` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `track_id` BIGINT NOT NULL COMMENT '歌曲ID',
  `played_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '播放时间',
  `position` INT DEFAULT 0 COMMENT '播放进度（秒）',
  `duration` INT DEFAULT 0 COMMENT '累计播放时长（秒）',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_user_played_at` (`user_id`, `played_at`),
  KEY `idx_track_id` (`track_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='播放记录表';

-- =============================================
-- 初始化测试数据
-- =============================================

-- 插入测试用户（密码：123456，使用BCrypt加密）
INSERT INTO `user` (`username`, `password_hash`, `nickname`, `status`) VALUES
('testuser', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '测试用户', 0);

INSERT INTO `user` (`username`, `password_hash`, `nickname`, `status`) VALUES
('bin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', 'chenbin', 0);

-- 插入测试歌手
INSERT INTO `artist` (`name`, `alias`) VALUES
('周杰伦', 'Jay Chou'),
('陈奕迅', 'Eason Chan');

-- 插入测试专辑
INSERT INTO `album` (`name`, `artist_id`, `year`) VALUES
('范特西', 1, 2001),
('七里香', 1, 2004);

-- 插入测试歌曲
INSERT INTO `track` (`title`, `artist_id`, `album_id`, `duration`, `file_path`, `audio_url`, `source_type`) VALUES
('爱在西元前', 1, 1, 290, '/music/爱在西元前.mp3', 'http://localhost:8080/audio/爱在西元前.mp3', 'LOCAL'),
('七里香', 1, 2, 315, '/music/七里香.mp3', 'http://localhost:8080/audio/七里香.mp3', 'LOCAL');

-- 插入测试文件夹
INSERT INTO `folder` (`name`, `path`) VALUES
('流行音乐', '/music/pop'),
('经典老歌', '/music/classic');

-- 关联歌曲到文件夹
INSERT INTO `track_folder` (`track_id`, `folder_id`) VALUES
(1, 1),
(2, 1);

-- 插入测试歌单
INSERT INTO `playlist` (`user_id`, `name`, `description`, `type`) VALUES
(1, '我喜欢的歌', '收藏的好听的歌曲', 'USER');

-- 关联歌曲到歌单
INSERT INTO `playlist_track` (`playlist_id`, `track_id`, `order_index`) VALUES
(1, 1, 1),
(1, 2, 2);
