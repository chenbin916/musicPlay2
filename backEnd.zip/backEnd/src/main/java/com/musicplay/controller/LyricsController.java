package com.musicplay.controller;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.musicplay.common.result.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/lyrics")
public class LyricsController {

  private static final ObjectMapper MAPPER = new ObjectMapper()
    .configure(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS, true);

  /**
   * 用 HttpURLConnection 直接发请求，携带浏览器头，返回原始响应字符串。
   * 完全绕开 Spring RestTemplate / Jackson 消息转换器。
   */
  private String httpGet(String urlStr) throws Exception {
    URL url = new URL(urlStr);
    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    conn.setRequestMethod("GET");
    conn.setConnectTimeout(8000);
    conn.setReadTimeout(8000);
    conn.setRequestProperty("User-Agent",
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
    conn.setRequestProperty("Referer", "https://music.163.com/");
    conn.setRequestProperty("Accept", "application/json, text/plain, */*");
    conn.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
    conn.connect();

    int code = conn.getResponseCode();
    log.info("HTTP {} -> {}", urlStr, code);

    InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
    java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
    byte[] tmp = new byte[4096];
    int n;
    while ((n = is.read(tmp)) != -1) {
      buf.write(tmp, 0, n);
    }
    is.close();
    conn.disconnect();
    return buf.toString(StandardCharsets.UTF_8.name());
  }

  @GetMapping("/search")
  public Result<Map<String, Object>> searchLyrics(@RequestParam String keyword) {
    log.info("搜索歌词，关键词: {}", keyword);

    try {
      String searchUrl = String.format(
        "https://music.163.com/api/search/get/web?csrf_token=&&s=%s&type=1&offset=0&total=true&limit=20",
        java.net.URLEncoder.encode(keyword, "UTF-8")
      );
      log.info("搜索 URL: {}", searchUrl);

      String rawBody = httpGet(searchUrl);
      log.info("原始响应(前500字符): {}", rawBody.length() > 500 ? rawBody.substring(0, 500) : rawBody);

      @SuppressWarnings("unchecked")
      Map<String, Object> searchResult = MAPPER.readValue(rawBody, Map.class);

      if (searchResult != null && searchResult.containsKey("result")) {
        @SuppressWarnings("unchecked")
        Map<String, Object> resultData = (Map<String, Object>) searchResult.get("result");

        log.info("songCount: {}", resultData != null ? resultData.get("songCount") : "null");

        if (resultData != null && resultData.containsKey("songs")) {
          @SuppressWarnings("unchecked")
          List<Map<String, Object>> songs = (List<Map<String, Object>>) resultData.get("songs");

          log.info("返回歌曲数量: {}", songs != null ? songs.size() : 0);

          if (songs != null && !songs.isEmpty()) {
            // 解析关键词：歌名-歌手名
            String titlePart = keyword;
            String artistPart = "";
            int dashIdx = keyword.lastIndexOf('-');
            if (dashIdx > 0) {
              titlePart = keyword.substring(0, dashIdx).trim();
              artistPart = keyword.substring(dashIdx + 1).trim();
            }
            String titleLower = titlePart.toLowerCase();
            String artistLower = artistPart.toLowerCase();

            for (int i = 0; i < songs.size(); i++) {
              Map<String, Object> s = songs.get(i);
              log.info("  [{}] id={} name={} artist={}", i, s.get("id"), s.get("name"), extractFirstArtist(s));
            }

            // 匹配策略：歌名+歌手都匹配 > 仅歌名匹配 > 第一首
            Map<String, Object> bestMatch = songs.get(0);
            Map<String, Object> titleOnlyMatch = null;

            for (Map<String, Object> song : songs) {
              String songName = String.valueOf(song.getOrDefault("name", "")).toLowerCase();
              String artistName = extractFirstArtist(song).toLowerCase();
              boolean titleMatch = songName.equals(titleLower)
                || songName.contains(titleLower)
                || titleLower.contains(songName);
              boolean artistMatch = !artistLower.isEmpty()
                && (artistName.contains(artistLower) || artistLower.contains(artistName));
              if (titleMatch && artistMatch) {
                bestMatch = song;
                break;
              }
              if (titleMatch && titleOnlyMatch == null) {
                titleOnlyMatch = song;
              }
            }
            if (bestMatch == songs.get(0) && titleOnlyMatch != null) {
              bestMatch = titleOnlyMatch;
            }

            log.info("最终选中: id={} name={}", bestMatch.get("id"), bestMatch.get("name"));
            Object songIdObj = bestMatch.get("id");

            if (songIdObj != null) {
              Long songId = ((Number) songIdObj).longValue();
              log.info("找到歌曲 ID: {}", songId);

              String lyricUrl = String.format(
                "https://music.163.com/api/song/lyric?id=%d&lv=1&kv=1&tv=-1", songId);
              log.info("歌词 URL: {}", lyricUrl);

              String lyricRaw = httpGet(lyricUrl);
              @SuppressWarnings("unchecked")
              Map<String, Object> lyricResult = MAPPER.readValue(lyricRaw, Map.class);

              Map<String, Object> response = new HashMap<>();
              response.put("success", true);
              response.put("songId", songId);
              response.put("lyricData", lyricResult);
              return Result.success(response);
            }
          }
        }
      }

      log.warn("未找到歌词");
      Map<String, Object> response = new HashMap<>();
      response.put("success", false);
      response.put("message", "未找到歌词");
      return Result.success(response);

    } catch (Exception e) {
      log.error("搜索歌词失败", e);
      Map<String, Object> response = new HashMap<>();
      response.put("success", false);
      response.put("message", "搜索失败: " + e.getMessage());
      return Result.success(response);
    }
  }

  @SuppressWarnings("unchecked")
  private String extractFirstArtist(Map<String, Object> song) {
    Object artistsObj = song.get("artists");
    if (artistsObj instanceof List) {
      List<Map<String, Object>> artists = (List<Map<String, Object>>) artistsObj;
      if (!artists.isEmpty()) {
        return String.valueOf(artists.get(0).getOrDefault("name", ""));
      }
    }
    return "";
  }
}
