package com.musicplay.controller;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.musicplay.common.result.Result;
import com.musicplay.dao.TrackMapper;
import com.musicplay.domain.Track;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequestMapping("/api/online")
@RequiredArgsConstructor
public class OnlineSearchController {

  private final TrackMapper trackMapper;

  @Value("${musicplay.scan.music-dir}")
  private String musicDir;

  private static final ObjectMapper MAPPER = new ObjectMapper()
      .configure(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS, true);

  // ---- 检测 audioUrl 是否可播放（读取前 4 字节检查 magic bytes，立即断开）----
  private boolean isPlayable(String urlStr) {
    HttpURLConnection conn = null;
    try {
      URL url = new URL(urlStr);
      conn = (HttpURLConnection) url.openConnection();
      conn.setInstanceFollowRedirects(true);
      conn.setRequestMethod("GET");
      conn.setConnectTimeout(8000);
      // ReadTimeout 足够大以便读到首批数据，但我们读到 4 字节立即 disconnect
      conn.setReadTimeout(10000);
      conn.setRequestProperty("User-Agent",
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
      conn.setRequestProperty("Referer", "https://music.163.com/");
      conn.connect();

      int status = conn.getResponseCode();
      String contentType = conn.getContentType();
      log.debug("isPlayable status={} contentType={} url={}", status, contentType, urlStr);

      if (status != 200 && status != 206) {
        return false;
      }

      // Content-Type 明确为 audio/，不用读字节
      if (contentType != null && contentType.startsWith("audio/")) {
        return true;
      }

      // 读取前 4 字节后立即 disconnect（终止传输，不等整个文件）
      byte[] header = new byte[4];
      int read = 0;
      try (InputStream is = conn.getInputStream()) {
        while (read < header.length) {
          int n = is.read(header, read, header.length - read);
          if (n == -1) break;
          read += n;
        }
      } finally {
        conn.disconnect(); // 读够就强制断开，不等传输完成
        conn = null;
      }

      if (read < 3) return false;

      // ID3 tag header (MP3)
      boolean isId3 = header[0] == 0x49 && header[1] == 0x44 && header[2] == 0x33;
      // MPEG frame sync
      boolean isMpeg = (header[0] & 0xFF) == 0xFF && (header[1] & 0xE0) == 0xE0;
      // fLaC
      boolean isFlac = read >= 4 && header[0] == 0x66 && header[1] == 0x4C && header[2] == 0x61 && header[3] == 0x43;
      // OGG
      boolean isOgg = header[0] == 0x4F && header[1] == 0x67 && header[2] == 0x67;

      boolean result = isId3 || isMpeg || isFlac || isOgg;
      log.debug("isPlayable bytes=[{},{},{},{}] result={} url={}",
          header[0] & 0xFF, header[1] & 0xFF, header[2] & 0xFF, read >= 4 ? header[3] & 0xFF : -1,
          result, urlStr);
      return result;
    } catch (Exception e) {
      log.debug("isPlayable error: {} -> {}", urlStr, e.getMessage());
      return false;
    } finally {
      if (conn != null) conn.disconnect();
    }
  }

  // ---- HTTP 工具 ----
  private String httpGet(String urlStr) throws Exception {
    URL url = new URL(urlStr);
    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    conn.setRequestMethod("GET");
    conn.setConnectTimeout(8000);
    conn.setReadTimeout(8000);
    conn.setRequestProperty("User-Agent",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
    conn.setRequestProperty("Referer", "https://music.163.com/");
    conn.setRequestProperty("Accept", "application/json, text/plain, */*");
    conn.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
    conn.connect();

    int code = conn.getResponseCode();
    log.info("HTTP {} -> {}", code, urlStr);

    InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
    java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
    byte[] tmp = new byte[4096];
    int n;
    while ((n = is.read(tmp)) != -1) buf.write(tmp, 0, n);
    is.close();
    conn.disconnect();
    return buf.toString(StandardCharsets.UTF_8.name());
  }

  /**
   * 在线搜索歌曲
   * GET /api/online/search?keyword=xxx&page=1&pageSize=30
   */
  @GetMapping("/search")
  public Result<List<Map<String, Object>>> search(
      @RequestParam String keyword,
      @RequestParam(defaultValue = "1") int page,
      @RequestParam(defaultValue = "30") int pageSize) {

    log.info("在线搜索: keyword={} page={} pageSize={}", keyword, page, pageSize);

    try {
      int offset = (page - 1) * pageSize;
      String searchUrl = String.format(
          "https://music.163.com/api/search/get/web?csrf_token=&s=%s&type=1&offset=%d&total=true&limit=%d",
          java.net.URLEncoder.encode(keyword, "UTF-8"), offset, pageSize);

      String rawBody = httpGet(searchUrl);
      log.info("搜索响应(前300字符): {}", rawBody.length() > 300 ? rawBody.substring(0, 300) : rawBody);

      @SuppressWarnings("unchecked")
      Map<String, Object> searchResult = MAPPER.readValue(rawBody, Map.class);

      List<Map<String, Object>> tracks = new ArrayList<>();

      if (searchResult != null && searchResult.containsKey("result")) {
        @SuppressWarnings("unchecked")
        Map<String, Object> resultData = (Map<String, Object>) searchResult.get("result");

        if (resultData != null && resultData.containsKey("songs")) {
          @SuppressWarnings("unchecked")
          List<Map<String, Object>> songs = (List<Map<String, Object>>) resultData.get("songs");

          if (songs != null) {
            for (Map<String, Object> song : songs) {
              try {
                Object idObj = song.get("id");
                if (idObj == null) continue;
                long songId = ((Number) idObj).longValue();

                String title = String.valueOf(song.getOrDefault("name", "未知歌曲"));
                String artistName = extractFirstArtist(song);
                String albumName = extractAlbumName(song);
                int duration = extractDuration(song);
                String coverUrl = extractCoverUrl(song);

                // 网易云音乐试听地址（128kbps，免版权歌曲可用）
                String audioUrl = String.format(
                    "https://music.163.com/song/media/outer/url?id=%d.mp3", songId);

                Map<String, Object> track = new LinkedHashMap<>();
                track.put("id", songId);
                track.put("title", title);
                track.put("artistName", artistName);
                track.put("albumName", albumName);
                track.put("duration", duration);
                track.put("audioUrl", audioUrl);
                track.put("coverUrl", coverUrl);

                tracks.add(track);
              } catch (Exception ex) {
                log.warn("解析单首歌曲失败: {}", ex.getMessage());
              }
            }
          }
        }
      }

      log.info("搜索完成，共 {} 首", tracks.size());
      return Result.success(tracks);

    } catch (Exception e) {
      log.error("在线搜索失败", e);
      return Result.success(Collections.emptyList());
    }
  }

  /**
   * 保存在线歌曲到本地磁盘并入库（sourceType=LOCAL）
   * POST /api/online/save
   * Body: { id, title, artistName, albumName, duration, audioUrl, coverUrl }
   */
  @PostMapping("/save")
  public Result<Map<String, Object>> saveOnlineTrack(@RequestBody Map<String, Object> body) {
    try {
      Object idObj = body.get("id");
      if (idObj == null) {
        return Result.error("缺少歌曲 id");
      }
      long onlineId = ((Number) idObj).longValue();
      String onlineAudioUrl = String.valueOf(body.getOrDefault("audioUrl", ""));
      String title = String.valueOf(body.getOrDefault("title", "未知歌曲"));

      // 文件名：用歌曲标题，去除非法字符，加 .mp3
      String safeTitle = title.replaceAll("[\\\\/:*?\"<>|]", "_");
      String fileName = safeTitle + "_" + onlineId + ".mp3";

      // 目标路径：music-dir/online/
      Path onlineDir = Paths.get(musicDir, "online");
      Files.createDirectories(onlineDir);
      Path destFile = onlineDir.resolve(fileName);

      // 去重：文件已存在 或 数据库已有相同 filePath，则直接返回
      String filePath = destFile.toString();
      Track existing = trackMapper.selectByFilePath(filePath);
      if (existing != null) {
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("id", existing.getId());
        resp.put("alreadyExists", true);
        return Result.success(resp);
      }

      // 下载 MP3 到本地
      log.info("开始下载: {} -> {}", onlineAudioUrl, destFile);
      downloadFile(onlineAudioUrl, destFile);
      log.info("下载完成: {}", destFile);

      // 构建本地访问 URL：/api/audio/online/filename.mp3
      String localAudioUrl = "/api/audio/online/" + fileName;

      // 入库
      Track track = new Track();
      track.setTitle(title);
      track.setFilePath(filePath);
      track.setAudioUrl(localAudioUrl);
      track.setCoverUrl(body.get("coverUrl") != null ? String.valueOf(body.get("coverUrl")) : null);
      track.setSourceType("LOCAL");

      Object durObj = body.get("duration");
      if (durObj instanceof Number) {
        track.setDuration(((Number) durObj).intValue());
      }

      trackMapper.insert(track);
      log.info("在线歌曲已保存到本地: id={} title={} file={}", onlineId, title, filePath);

      Map<String, Object> resp = new LinkedHashMap<>();
      resp.put("id", track.getId());
      resp.put("alreadyExists", false);
      return Result.success(resp);

    } catch (Exception e) {
      log.error("保存在线歌曲失败", e);
      return Result.error("保存失败：" + e.getMessage());
    }
  }

  /**
   * 下载文件到指定路径（跟随重定向）
   */
  private void downloadFile(String urlStr, Path dest) throws Exception {
    URL url = new URL(urlStr);
    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    conn.setInstanceFollowRedirects(true);
    conn.setRequestMethod("GET");
    conn.setConnectTimeout(15000);
    conn.setReadTimeout(60000);
    conn.setRequestProperty("User-Agent",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
    conn.setRequestProperty("Referer", "https://music.163.com/");

    int status = conn.getResponseCode();
    // 手动处理重定向（https -> http 等跨协议情况）
    if (status == HttpURLConnection.HTTP_MOVED_TEMP
        || status == HttpURLConnection.HTTP_MOVED_PERM
        || status == 307 || status == 308) {
      String newUrl = conn.getHeaderField("Location");
      conn.disconnect();
      if (newUrl != null) {
        downloadFile(newUrl, dest);
        return;
      }
    }

    try (InputStream in = conn.getInputStream()) {
      Files.copy(in, dest, StandardCopyOption.REPLACE_EXISTING);
    } finally {
      conn.disconnect();
    }
  }



  @SuppressWarnings("unchecked")
  private String extractFirstArtist(Map<String, Object> song) {
    Object artistsObj = song.get("artists");
    if (artistsObj instanceof List) {
      List<Map<String, Object>> artists = (List<Map<String, Object>>) artistsObj;
      if (!artists.isEmpty()) {
        return String.valueOf(artists.get(0).getOrDefault("name", "未知艺术家"));
      }
    }
    return "未知艺术家";
  }

  @SuppressWarnings("unchecked")
  private String extractAlbumName(Map<String, Object> song) {
    Object albumObj = song.get("album");
    if (albumObj instanceof Map) {
      Map<String, Object> album = (Map<String, Object>) albumObj;
      return String.valueOf(album.getOrDefault("name", ""));
    }
    return "";
  }

  @SuppressWarnings("unchecked")
  private String extractCoverUrl(Map<String, Object> song) {
    Object albumObj = song.get("album");
    if (albumObj instanceof Map) {
      Map<String, Object> album = (Map<String, Object>) albumObj;
      Object picUrl = album.get("picUrl");
      if (picUrl != null && !picUrl.toString().isEmpty()) {
        return picUrl.toString();
      }
    }
    return null;
  }

  private int extractDuration(Map<String, Object> song) {
    Object durationObj = song.get("duration");
    if (durationObj instanceof Number) {
      // 网易云返回毫秒，转换为秒
      return (int) (((Number) durationObj).longValue() / 1000);
    }
    return 0;
  }
}
