package com.musicplay.controller;

import com.musicplay.common.result.Result;
import com.musicplay.dto.PlaybackRecordRequest;
import com.musicplay.security.SecurityUtil;
import com.musicplay.service.PlaybackService;
import com.musicplay.vo.PlaybackRecordVO;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/playback")
@RequiredArgsConstructor
public class PlaybackController {

  private final PlaybackService playbackService;

  @PostMapping("/records")
  public Result<Void> recordPlayback(@Validated @RequestBody PlaybackRecordRequest request) {
    Long userId = SecurityUtil.getCurrentUserId();
    playbackService.recordPlayback(userId, request.getTrackId(), request.getPosition(), request.getDuration());
    return Result.success();
  }

  @GetMapping("/recent")
  public Result<List<PlaybackRecordVO>> listRecentPlayback(
      @RequestParam(defaultValue = "20") int limit) {
    Long userId = SecurityUtil.getCurrentUserId();
    List<PlaybackRecordVO> records = playbackService.listRecentPlayback(userId, limit);
    return Result.success(records);
  }
}
