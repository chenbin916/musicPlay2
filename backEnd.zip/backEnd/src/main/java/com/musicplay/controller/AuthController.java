package com.musicplay.controller;

import com.musicplay.dto.UserLoginRequest;
import com.musicplay.dto.UserLoginResponse;
import com.musicplay.common.result.Result;
import com.musicplay.domain.User;
import com.musicplay.security.JwtTokenService;
import com.musicplay.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

  private final UserService userService;
  private final JwtTokenService jwtTokenService;

  @PostMapping("/login")
  public Result<UserLoginResponse> login(@Validated @RequestBody UserLoginRequest request) {
    User user = userService.login(request.getUsername(), request.getPassword());
    String token = jwtTokenService.generateToken(user.getId(), user.getUsername());

    UserLoginResponse response = new UserLoginResponse();
    response.setToken(token);
    response.setUserId(user.getId());
    response.setUsername(user.getUsername());
    response.setNickname(user.getNickname());
    return Result.success(response);
  }

  @GetMapping("/me")
  public Result<com.musicplay.vo.UserVO> getCurrentUser() {
    Long userId = com.musicplay.security.SecurityUtil.getCurrentUserId();
    User user = userService.selectById(userId);
    com.musicplay.vo.UserVO vo = new com.musicplay.vo.UserVO();
    vo.setId(user.getId());
    vo.setUsername(user.getUsername());
    vo.setNickname(user.getNickname());
    return Result.success(vo);
  }
}
