package com.musicplay.controller;

import com.musicplay.common.result.Result;
import com.musicplay.service.FolderService;
import com.musicplay.vo.FolderVO;
import com.musicplay.vo.TrackVO;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/folders")
@RequiredArgsConstructor
public class FolderController {

  private final FolderService folderService;

  @GetMapping
  public Result<List<FolderVO>> listFolders() {
    List<FolderVO> folders = folderService.listFolders();
    return Result.success(folders);
  }

  @GetMapping("/{id}")
  public Result<FolderVO> getFolderById(@PathVariable Long id) {
    FolderVO folder = folderService.getFolderById(id);
    return Result.success(folder);
  }

  @GetMapping("/{id}/tracks")
  public Result<List<TrackVO>> listFolderTracks(@PathVariable Long id) {
    List<TrackVO> tracks = folderService.listFolderTracks(id);
    return Result.success(tracks);
  }
}
