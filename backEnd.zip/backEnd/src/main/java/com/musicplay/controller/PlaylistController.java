package com.musicplay.controller;

import com.musicplay.common.result.Result;
import com.musicplay.dto.AddTrackToPlaylistRequest;
import com.musicplay.dto.PlaylistCreateRequest;
import com.musicplay.dto.PlaylistUpdateRequest;
import com.musicplay.security.SecurityUtil;
import com.musicplay.service.PlaylistService;
import com.musicplay.vo.PlaylistVO;
import com.musicplay.vo.TrackVO;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/playlists")
@RequiredArgsConstructor
public class PlaylistController {

  private final PlaylistService playlistService;

  @GetMapping
  public Result<List<PlaylistVO>> listPlaylists(
      @RequestParam(required = false) String type) {
    Long userId = SecurityUtil.getCurrentUserId();
    List<PlaylistVO> playlists = playlistService.listPlaylists(userId, type);
    return Result.success(playlists);
  }

  @PostMapping
  public Result<Void> createPlaylist(@Validated @RequestBody PlaylistCreateRequest request) {
    Long userId = SecurityUtil.getCurrentUserId();
    playlistService.createPlaylist(userId, request.getName(), request.getDescription());
    return Result.success();
  }

  @PutMapping("/{id}")
  public Result<Void> updatePlaylist(
      @PathVariable Long id,
      @RequestBody PlaylistUpdateRequest request) {
    Long userId = SecurityUtil.getCurrentUserId();
    playlistService.updatePlaylist(userId, id, request.getName(), request.getDescription());
    return Result.success();
  }

  @DeleteMapping("/{id}")
  public Result<Void> deletePlaylist(@PathVariable Long id) {
    Long userId = SecurityUtil.getCurrentUserId();
    playlistService.deletePlaylist(userId, id);
    return Result.success();
  }

  @GetMapping("/{id}/tracks")
  public Result<List<TrackVO>> listPlaylistTracks(@PathVariable Long id) {
    Long userId = SecurityUtil.getCurrentUserId();
    List<TrackVO> tracks = playlistService.listPlaylistTracks(userId, id);
    return Result.success(tracks);
  }

  @PostMapping("/{id}/tracks")
  public Result<Void> addTrackToPlaylist(
      @PathVariable Long id,
      @Validated @RequestBody AddTrackToPlaylistRequest request) {
    Long userId = SecurityUtil.getCurrentUserId();
    playlistService.addTrackToPlaylist(userId, id, request.getTrackId(), request.getOrderIndex());
    return Result.success();
  }

  @DeleteMapping("/{id}/tracks/{trackId}")
  public Result<Void> removeTrackFromPlaylist(
      @PathVariable Long id,
      @PathVariable Long trackId) {
    Long userId = SecurityUtil.getCurrentUserId();
    playlistService.removeTrackFromPlaylist(userId, id, trackId);
    return Result.success();
  }
}
