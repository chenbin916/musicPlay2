package com.musicplay.controller;

import com.musicplay.common.result.PageResult;
import com.musicplay.common.result.Result;
import com.musicplay.dto.RebuildIndexResponse;
import com.musicplay.dto.ScanResultResponse;
import com.musicplay.security.SecurityUtil;
import com.musicplay.service.TrackService;
import com.musicplay.vo.TrackVO;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tracks")
@RequiredArgsConstructor
public class TrackController {

  private final TrackService trackService;

  @GetMapping
  public Result<PageResult<TrackVO>> listTracks(
      @RequestParam(required = false) String keyword,
      @RequestParam(required = false) Long artistId,
      @RequestParam(required = false) Long albumId,
      @RequestParam(defaultValue = "1") Long current,
      @RequestParam(defaultValue = "20") Long size) {
    PageResult<TrackVO> result = trackService.listTracks(keyword, artistId, albumId, current, size);
    return Result.success(result);
  }

  @GetMapping("/{id}")
  public Result<TrackVO> getTrackById(@PathVariable Long id) {
    TrackVO track = trackService.getTrackById(id);
    return Result.success(track);
  }

  @PostMapping("/scan")
  public Result<ScanResultResponse> scanMusicFiles() {
    int count = trackService.scanMusicFiles();
    ScanResultResponse response = new ScanResultResponse();
    response.setMessage("扫描完成");
    response.setCount(count);
    return Result.success(response);
  }

  @PostMapping("/rebuild")
  public Result<RebuildIndexResponse> rebuildIndex() {
    trackService.rebuildIndex();
    RebuildIndexResponse response = new RebuildIndexResponse();
    response.setMessage("索引重建完成");
    return Result.success(response);
  }
}
