package com.musicplay.service.impl;

import com.musicplay.dao.PlaybackRecordMapper;
import com.musicplay.dao.TrackMapper;
import com.musicplay.dao.ArtistMapper;
import com.musicplay.domain.Artist;
import com.musicplay.domain.PlaybackRecord;
import com.musicplay.domain.Track;
import com.musicplay.service.PlaybackService;
import com.musicplay.vo.PlaybackRecordVO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PlaybackServiceImpl implements PlaybackService {

  private final PlaybackRecordMapper playbackRecordMapper;
  private final TrackMapper trackMapper;
  private final ArtistMapper artistMapper;

  @Override
  @Transactional
  public void recordPlayback(Long userId, Long trackId, Integer position, Integer duration) {
    PlaybackRecord record = new PlaybackRecord();
    record.setUserId(userId);
    record.setTrackId(trackId);
    record.setPosition(position);
    record.setDuration(duration);
    playbackRecordMapper.insert(record);
  }

  @Override
  public List<PlaybackRecordVO> listRecentPlayback(Long userId, int limit) {
    List<PlaybackRecord> records = playbackRecordMapper.selectRecentByUserId(userId, limit);

    List<Long> trackIds = records.stream()
        .map(PlaybackRecord::getTrackId)
        .distinct()
        .collect(Collectors.toList());

    List<Track> tracks = trackIds.stream()
        .map(trackMapper::selectById)
        .collect(Collectors.toList());

    Map<Long, Track> trackMap = tracks.stream()
        .collect(Collectors.toMap(Track::getId, t -> t));

    Map<Long, Artist> artistMap = tracks.stream()
        .filter(t -> t.getArtistId() != null)
        .map(t -> artistMapper.selectById(t.getArtistId()))
        .filter(a -> a != null)
        .collect(Collectors.toMap(Artist::getId, a -> a));

    return records.stream().map(record -> {
      PlaybackRecordVO vo = new PlaybackRecordVO();
      BeanUtils.copyProperties(record, vo);
      Track track = trackMap.get(record.getTrackId());
      if (track != null) {
        vo.setTrackTitle(track.getTitle());
        Artist artist = artistMap.get(track.getArtistId());
        if (artist != null) {
          vo.setArtistName(artist.getName());
        }
      }
      return vo;
    }).collect(Collectors.toList());
  }
}
