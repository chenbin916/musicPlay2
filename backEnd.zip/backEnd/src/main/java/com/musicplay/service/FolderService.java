package com.musicplay.service;

import com.musicplay.vo.FolderVO;
import com.musicplay.vo.TrackVO;

import java.util.List;

public interface FolderService {
  List<FolderVO> listFolders();
  FolderVO getFolderById(Long id);
  List<TrackVO> listFolderTracks(Long id);
}
