package com.musicplay.service;

import com.musicplay.common.result.PageResult;
import com.musicplay.domain.Playlist;
import com.musicplay.vo.PlaylistVO;
import com.musicplay.vo.TrackVO;

import java.util.List;

public interface PlaylistService {
  List<PlaylistVO> listPlaylists(Long userId, String type);
  Playlist createPlaylist(Long userId, String name, String description);
  void updatePlaylist(Long userId, Long playlistId, String name, String description);
  void deletePlaylist(Long userId, Long playlistId);
  List<TrackVO> listPlaylistTracks(Long userId, Long playlistId);
  void addTrackToPlaylist(Long userId, Long playlistId, Long trackId, Integer orderIndex);
  void removeTrackFromPlaylist(Long userId, Long playlistId, Long trackId);
}
