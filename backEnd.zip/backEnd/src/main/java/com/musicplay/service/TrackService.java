package com.musicplay.service;

import com.musicplay.common.result.PageResult;
import com.musicplay.domain.Track;
import com.musicplay.vo.TrackVO;

import java.util.List;

public interface TrackService {
  TrackVO getTrackById(Long id);
  PageResult<TrackVO> listTracks(String keyword, Long artistId, Long albumId, Long current, Long size);
  List<TrackVO> listTracksByFolder(Long folderId);
  int scanMusicFiles();
  void rebuildIndex();
}
