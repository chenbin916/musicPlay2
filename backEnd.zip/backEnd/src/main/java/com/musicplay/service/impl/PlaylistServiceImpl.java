package com.musicplay.service.impl;

import com.musicplay.common.exception.BizException;
import com.musicplay.dao.PlaylistMapper;
import com.musicplay.dao.PlaylistTrackMapper;
import com.musicplay.dao.TrackMapper;
import com.musicplay.domain.Playlist;
import com.musicplay.domain.PlaylistTrack;
import com.musicplay.domain.Track;
import com.musicplay.service.PlaylistService;
import com.musicplay.vo.PlaylistVO;
import com.musicplay.vo.TrackVO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PlaylistServiceImpl implements PlaylistService {

  private final PlaylistMapper playlistMapper;
  private final PlaylistTrackMapper playlistTrackMapper;
  private final TrackMapper trackMapper;

  @Override
  public List<PlaylistVO> listPlaylists(Long userId, String type) {
    List<Playlist> playlists = playlistMapper.selectByUserIdAndQuery(userId, type);
    return playlists.stream().map(this::convertToVO).collect(Collectors.toList());
  }

  @Override
  @Transactional
  public Playlist createPlaylist(Long userId, String name, String description) {
    Playlist playlist = new Playlist();
    playlist.setUserId(userId);
    playlist.setName(name);
    playlist.setDescription(description);
    playlist.setType("USER");
    playlistMapper.insert(playlist);
    return playlist;
  }

  @Override
  @Transactional
  public void updatePlaylist(Long userId, Long playlistId, String name, String description) {
    Playlist playlist = playlistMapper.selectByIdAndUserId(playlistId, userId);
    if (playlist == null) {
      throw new BizException("歌单不存在");
    }
    if (name != null) {
      playlist.setName(name);
    }
    if (description != null) {
      playlist.setDescription(description);
    }
    playlistMapper.update(playlist);
  }

  @Override
  @Transactional
  public void deletePlaylist(Long userId, Long playlistId) {
    Playlist playlist = playlistMapper.selectByIdAndUserId(playlistId, userId);
    if (playlist == null) {
      throw new BizException("歌单不存在");
    }
    playlistTrackMapper.deleteByPlaylistId(playlistId);
    playlistMapper.deleteByIdAndUserId(playlistId, userId);
  }

  @Override
  public List<TrackVO> listPlaylistTracks(Long userId, Long playlistId) {
    Playlist playlist = playlistMapper.selectByIdAndUserId(playlistId, userId);
    if (playlist == null) {
      throw new BizException("歌单不存在");
    }
    List<PlaylistTrack> playlistTracks = playlistTrackMapper.selectByPlaylistId(playlistId);
    if (CollectionUtils.isEmpty(playlistTracks)) {
      return new ArrayList<>();
    }
    List<Long> trackIds = playlistTracks.stream()
        .map(PlaylistTrack::getTrackId)
        .collect(Collectors.toList());
    return trackIds.stream().map(trackId -> {
      if (trackId < 0) {
        // 本地音乐（负数 id），数据库中无记录，返回占位 VO，前端凭 id 从 localStorage 取完整信息
        TrackVO vo = new TrackVO();
        vo.setId(trackId);
        vo.setSourceType("local");
        vo.setTitle("本地音乐");
        vo.setArtistName("本地音乐");
        return vo;
      }
      Track track = trackMapper.selectById(trackId);
      if (track == null) return null;
      TrackVO vo = new TrackVO();
      BeanUtils.copyProperties(track, vo);
      return vo;
    }).filter(vo -> vo != null).collect(Collectors.toList());
  }

  @Override
  @Transactional
  public void addTrackToPlaylist(Long userId, Long playlistId, Long trackId, Integer orderIndex) {
    Playlist playlist = playlistMapper.selectByIdAndUserId(playlistId, userId);
    if (playlist == null) {
      throw new BizException("歌单不存在");
    }
    // 本地音乐 id 为负数，不在数据库中，跳过校验；服务器歌曲才需要验证存在性
    if (trackId > 0) {
      Track track = trackMapper.selectById(trackId);
      if (track == null) {
        throw new BizException("歌曲不存在");
      }
    }
    if (orderIndex == null) {
      Integer maxOrder = playlistTrackMapper.selectMaxOrderIndex(playlistId);
      orderIndex = (maxOrder == null ? 0 : maxOrder) + 1;
    }
    PlaylistTrack playlistTrack = new PlaylistTrack();
    playlistTrack.setPlaylistId(playlistId);
    playlistTrack.setTrackId(trackId);
    playlistTrack.setOrderIndex(orderIndex);
    playlistTrackMapper.insert(playlistTrack);
  }

  @Override
  @Transactional
  public void removeTrackFromPlaylist(Long userId, Long playlistId, Long trackId) {
    Playlist playlist = playlistMapper.selectByIdAndUserId(playlistId, userId);
    if (playlist == null) {
      throw new BizException("歌单不存在");
    }
    playlistTrackMapper.deleteByPlaylistAndTrack(playlistId, trackId);
  }

  private PlaylistVO convertToVO(Playlist playlist) {
    PlaylistVO vo = new PlaylistVO();
    BeanUtils.copyProperties(playlist, vo);
    Long trackCount = playlistMapper.selectTrackCount(playlist.getId());
    vo.setTrackCount(trackCount.intValue());
    return vo;
  }
}
