package com.musicplay.service.impl;

import com.musicplay.common.exception.BizException;
import com.musicplay.dao.UserMapper;
import com.musicplay.domain.User;
import com.musicplay.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

  private final UserMapper userMapper;
  private final PasswordEncoder passwordEncoder;

  @Override
  public User login(String username, String rawPassword) {
    User user = selectByUsername(username);
    if (user == null) {
      throw new BizException("用户名或密码错误");
    }
    if (!passwordEncoder.matches(rawPassword, user.getPasswordHash())) {
      throw new BizException("用户名或密码错误");
    }
    return user;
  }

  @Override
  public User selectById(Long id) {
    return userMapper.selectById(id);
  }

  @Override
  public User selectByUsername(String username) {
    return userMapper.selectByUsername(username);
  }
}
