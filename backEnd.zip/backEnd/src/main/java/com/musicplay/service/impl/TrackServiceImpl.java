package com.musicplay.service.impl;

import com.musicplay.common.result.PageResult;
import com.musicplay.dao.AlbumMapper;
import com.musicplay.dao.ArtistMapper;
import com.musicplay.dao.FolderMapper;
import com.musicplay.dao.TrackMapper;
import com.musicplay.domain.Album;
import com.musicplay.domain.Artist;
import com.musicplay.domain.Track;
import com.musicplay.service.TrackService;
import com.musicplay.vo.TrackVO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TrackServiceImpl implements TrackService {

  private final TrackMapper trackMapper;
  private final ArtistMapper artistMapper;
  private final AlbumMapper albumMapper;
  private final FolderMapper folderMapper;

  @Value("${musicplay.scan.music-dir}")
  private String musicDir;

  @Value("${musicplay.scan.audio-extensions}")
  private String audioExtensions;

  private static final Map<String, String> FILE_EXTENSION_TO_FORMAT = new HashMap<>();
  static {
    FILE_EXTENSION_TO_FORMAT.put("mp3", "MPEG");
    FILE_EXTENSION_TO_FORMAT.put("wav", "WAV");
    FILE_EXTENSION_TO_FORMAT.put("ogg", "OGG");
    FILE_EXTENSION_TO_FORMAT.put("m4a", "M4A");
    FILE_EXTENSION_TO_FORMAT.put("flac", "FLAC");
  }

  @Override
  public TrackVO getTrackById(Long id) {
    Track track = trackMapper.selectById(id);
    if (track == null) {
      return null;
    }
    return convertToVO(track);
  }

  @Override
  public PageResult<TrackVO> listTracks(String keyword, Long artistId, Long albumId, Long current, Long size) {
    Long offset = (current - 1) * size;
    List<Track> tracks = trackMapper.selectPageByQuery(keyword, artistId, albumId, offset, size);
    Long total = trackMapper.selectCountByQuery(keyword, artistId, albumId);

    List<TrackVO> vos = tracks.stream().map(this::convertToVO).collect(Collectors.toList());
    return PageResult.of(vos, total, current, size);
  }

  @Override
  public List<TrackVO> listTracksByFolder(Long folderId) {
    List<Track> tracks = trackMapper.selectByFolderId(folderId);
    return tracks.stream().map(this::convertToVO).collect(Collectors.toList());
  }

  @Override
  public int scanMusicFiles() {
    String[] extensions = audioExtensions.split(",");
    Set<String> allowedExtensions = new HashSet<>(Arrays.asList(extensions));

    Path musicPath = Paths.get(musicDir);
    if (!Files.exists(musicPath)) {
      throw new RuntimeException("音乐目录不存在: " + musicDir);
    }

    int scannedCount = 0;
    try {
      List<Path> audioFiles = new ArrayList<>();
      Files.walk(musicPath)
        .filter(Files::isRegularFile)
        .filter(p -> {
          String fileName = p.getFileName().toString().toLowerCase();
          String extension = fileName.substring(fileName.lastIndexOf('.') + 1);
          return allowedExtensions.contains(extension);
        })
        .forEach(audioFiles::add);

      for (Path audioFile : audioFiles) {
        try {
          String filePath = audioFile.toString();
          Track existingTrack = trackMapper.selectByFilePath(filePath);

          if (existingTrack == null) {
            Track track = new Track();
            String fileName = audioFile.getFileName().toString();
            String title = fileName.substring(0, fileName.lastIndexOf('.'));

            track.setTitle(title);
            track.setFilePath(filePath);
            // 确保路径使用正斜杠
            String relativePath = Paths.get(musicDir).relativize(audioFile).toString().replace("\\", "/");
            track.setAudioUrl("/api/audio/" + relativePath);
            track.setSourceType("LOCAL");
            track.setDuration(180);
            track.setBitrate(128);

            System.out.println("添加歌曲: " + title + ", URL: " + track.getAudioUrl());
            System.out.println("  原始路径: " + filePath);
            trackMapper.insert(track);
            scannedCount++;
          }
        } catch (Exception e) {
          System.err.println("处理文件失败: " + audioFile + ", 错误: " + e.getMessage());
        }
      }
    } catch (Exception e) {
      throw new RuntimeException("扫描音乐文件失败: " + e.getMessage(), e);
    }

    return scannedCount;
  }

  @Override
  public void rebuildIndex() {
    try {
      List<Track> allTracks = trackMapper.selectPageByQuery(null, null, null, 0L, 100000L);

      for (Track track : allTracks) {
        File file = new File(track.getFilePath());
        if (!file.exists()) {
          trackMapper.deleteById(track.getId());
        }
      }
    } catch (Exception e) {
      throw new RuntimeException("重建索引失败: " + e.getMessage(), e);
    }
  }

  private TrackVO convertToVO(Track track) {
    TrackVO vo = new TrackVO();
    BeanUtils.copyProperties(track, vo);

    if (track.getArtistId() != null) {
      Artist artist = artistMapper.selectById(track.getArtistId());
      if (artist != null) {
        vo.setArtistName(artist.getName());
      }
    }

    if (track.getAlbumId() != null) {
      Album album = albumMapper.selectById(track.getAlbumId());
      if (album != null) {
        vo.setAlbumName(album.getName());
        vo.setCoverUrl(album.getCoverUrl());
      }
    }

    return vo;
  }
}
