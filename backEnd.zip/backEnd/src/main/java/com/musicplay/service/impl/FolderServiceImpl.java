package com.musicplay.service.impl;

import com.musicplay.dao.AlbumMapper;
import com.musicplay.dao.ArtistMapper;
import com.musicplay.dao.FolderMapper;
import com.musicplay.dao.TrackMapper;
import com.musicplay.domain.Album;
import com.musicplay.domain.Artist;
import com.musicplay.domain.Folder;
import com.musicplay.domain.Track;
import com.musicplay.service.FolderService;
import com.musicplay.vo.FolderVO;
import com.musicplay.vo.TrackVO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FolderServiceImpl implements FolderService {

  private final FolderMapper folderMapper;
  private final TrackMapper trackMapper;
  private final ArtistMapper artistMapper;
  private final AlbumMapper albumMapper;

  @Override
  public List<FolderVO> listFolders() {
    List<Folder> folders = folderMapper.selectAll();
    return folders.stream().map(this::convertToVO).collect(Collectors.toList());
  }

  @Override
  public FolderVO getFolderById(Long id) {
    Folder folder = folderMapper.selectById(id);
    if (folder == null) {
      return null;
    }
    return convertToVO(folder);
  }

  @Override
  public List<TrackVO> listFolderTracks(Long id) {
    List<Track> tracks = trackMapper.selectByFolderId(id);
    return tracks.stream().map(this::convertToTrackVO).collect(Collectors.toList());
  }

  private FolderVO convertToVO(Folder folder) {
    FolderVO vo = new FolderVO();
    BeanUtils.copyProperties(folder, vo);
    Integer trackCount = folderMapper.selectTrackCount(folder.getId()).intValue();
    vo.setTrackCount(trackCount);
    return vo;
  }

  private TrackVO convertToTrackVO(Track track) {
    TrackVO vo = new TrackVO();
    BeanUtils.copyProperties(track, vo);

    if (track.getArtistId() != null) {
      Artist artist = artistMapper.selectById(track.getArtistId());
      if (artist != null) {
        vo.setArtistName(artist.getName());
      }
    }

    if (track.getAlbumId() != null) {
      Album album = albumMapper.selectById(track.getAlbumId());
      if (album != null) {
        vo.setAlbumName(album.getName());
        vo.setCoverUrl(album.getCoverUrl());
      }
    }

    return vo;
  }
}
