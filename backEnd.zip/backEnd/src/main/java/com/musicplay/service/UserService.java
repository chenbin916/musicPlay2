package com.musicplay.service;

import com.musicplay.domain.User;

public interface UserService {
  User login(String username, String rawPassword);
  User selectById(Long id);
  User selectByUsername(String username);
}
