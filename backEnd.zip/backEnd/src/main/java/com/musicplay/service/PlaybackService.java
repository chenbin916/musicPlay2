package com.musicplay.service;

import com.musicplay.domain.PlaybackRecord;
import com.musicplay.vo.PlaybackRecordVO;

import java.util.List;

public interface PlaybackService {
  void recordPlayback(Long userId, Long trackId, Integer position, Integer duration);
  List<PlaybackRecordVO> listRecentPlayback(Long userId, int limit);
}
