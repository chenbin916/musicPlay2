package com.musicplay.vo;

import lombok.Data;

@Data
public class PlaylistVO {
  private Long id;
  private String name;
  private String description;
  private String type;
  private String coverUrl;
  private Integer trackCount;
}
