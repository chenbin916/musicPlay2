package com.musicplay.vo;

import lombok.Data;

@Data
public class UserVO {
  private Long id;
  private String username;
  private String nickname;
}
