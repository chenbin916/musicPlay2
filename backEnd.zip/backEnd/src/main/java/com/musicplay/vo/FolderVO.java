package com.musicplay.vo;

import lombok.Data;

@Data
public class FolderVO {
  private Long id;
  private String name;
  private String path;
  private Integer trackCount;
}
