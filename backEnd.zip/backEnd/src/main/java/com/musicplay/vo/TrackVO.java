package com.musicplay.vo;

import lombok.Data;

@Data
public class TrackVO {
  private Long id;
  private String title;
  private String artistName;
  private String albumName;
  private Integer duration;
  private String audioUrl;
  private String sourceType;
  private String coverUrl;
}
