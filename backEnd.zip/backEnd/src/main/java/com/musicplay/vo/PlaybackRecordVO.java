package com.musicplay.vo;

import lombok.Data;

import java.util.Date;

@Data
public class PlaybackRecordVO {
  private Long id;
  private Long trackId;
  private String trackTitle;
  private String artistName;
  private Date playedAt;
  private Integer position;
  private Integer duration;
}
