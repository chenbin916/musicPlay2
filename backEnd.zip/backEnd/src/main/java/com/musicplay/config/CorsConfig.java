package com.musicplay.config;

// CORS 配置已统一移至 SecurityConfig.corsConfigurationSource()
// 此文件保留为空，避免与 Spring Security CORS 配置冲突
public class CorsConfig {
}
