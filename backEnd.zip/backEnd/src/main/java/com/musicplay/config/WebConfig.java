package com.musicplay.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.resource.PathResourceResolver;

import java.nio.file.Paths;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Value("${musicplay.scan.music-dir}")
    private String musicDir;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 统一转为 file:/ 开头的 URI 格式，兼容 Windows 和 Linux
        String path = Paths.get(musicDir).toAbsolutePath().normalize().toString()
                .replace("\\", "/");
        // Windows: E:/Music  ->  file:/E:/Music/
        // Linux:   /chenbin/musicplay/music  ->  file:/chenbin/musicplay/music/
        String resourceLocation = "file:/" + path + "/";

        System.out.println("Configuring audio resource handler:");
        System.out.println("  Pattern: /api/audio/**");
        System.out.println("  Location: " + resourceLocation);

        registry.addResourceHandler("/api/audio/**")
                .addResourceLocations(resourceLocation)
                .setCachePeriod(0)
                .resourceChain(true)
                .addResolver(new PathResourceResolver());
    }
}
