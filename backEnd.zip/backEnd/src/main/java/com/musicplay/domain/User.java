package com.musicplay.domain;

import lombok.Data;
import java.util.Date;

@Data
public class User {
  private Long id;
  private String username;
  private String passwordHash;
  private String nickname;
  private Integer status;
  private Date createdAt;
  private Date updatedAt;
}
