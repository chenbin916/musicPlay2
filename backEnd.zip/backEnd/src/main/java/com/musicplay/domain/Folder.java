package com.musicplay.domain;

import lombok.Data;
import java.util.Date;

@Data
public class Folder {
  private Long id;
  private String name;
  private String path;
  private Date createdAt;
}
