package com.musicplay.domain;

import lombok.Data;
import java.util.Date;

@Data
public class Track {
  private Long id;
  private String title;
  private Long artistId;
  private Long albumId;
  private Integer duration;
  private Integer bitrate;
  private String filePath;
  private String audioUrl;
  private String coverUrl;
  private String sourceType;
  private Date createdAt;
  private Date updatedAt;
}
