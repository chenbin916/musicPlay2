package com.musicplay.domain;

import lombok.Data;
import java.util.Date;

@Data
public class Artist {
  private Long id;
  private String name;
  private String alias;
  private Date createdAt;
}
