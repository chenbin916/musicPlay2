package com.musicplay.domain;

import lombok.Data;
import java.util.Date;

@Data
public class Album {
  private Long id;
  private String name;
  private Long artistId;
  private String coverUrl;
  private Integer year;
  private Date createdAt;
}
