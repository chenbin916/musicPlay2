package com.musicplay.domain;

import lombok.Data;
import java.util.Date;

@Data
public class Playlist {
  private Long id;
  private Long userId;
  private String name;
  private String description;
  private String coverUrl;
  private String type;
  private Date createdAt;
  private Date updatedAt;
}
