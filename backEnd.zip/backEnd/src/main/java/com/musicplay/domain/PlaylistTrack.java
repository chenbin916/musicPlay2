package com.musicplay.domain;

import lombok.Data;
import java.util.Date;

@Data
public class PlaylistTrack {
  private Long id;
  private Long playlistId;
  private Long trackId;
  private Integer orderIndex;
  private Date createdAt;
}
