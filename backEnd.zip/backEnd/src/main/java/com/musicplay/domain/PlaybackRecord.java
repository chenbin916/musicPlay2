package com.musicplay.domain;

import lombok.Data;
import java.util.Date;

@Data
public class PlaybackRecord {
  private Long id;
  private Long userId;
  private Long trackId;
  private Date playedAt;
  private Integer position;
  private Integer duration;
}
