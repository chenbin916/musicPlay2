package com.musicplay;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.musicplay.dao")
public class MusicPlayApplication {
  public static void main(String[] args) {
    SpringApplication.run(MusicPlayApplication.class, args);
  }
}
