package com.musicplay.security;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MusicPlayPrincipal {
  private Long userId;
  private String username;
}
