package com.musicplay.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;

@Component
public class JwtTokenService {
  private final Key key;
  private final long expireMillis;

  public JwtTokenService(
      @Value("${musicplay.jwt.secret}") String secret,
      @Value("${musicplay.jwt.expireSeconds}") long expireSeconds
  ) {
    this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    this.expireMillis = expireSeconds * 1000L;
  }

  public String generateToken(Long userId, String username) {
    Date now = new Date();
    Date exp = new Date(now.getTime() + expireMillis);
    return Jwts.builder()
        .setSubject(String.valueOf(userId))
        .claim("username", username)
        .setIssuedAt(now)
        .setExpiration(exp)
        .signWith(key, SignatureAlgorithm.HS256)
        .compact();
  }

  public Claims parseClaims(String token) {
    return Jwts.parserBuilder()
        .setSigningKey(key)
        .build()
        .parseClaimsJws(token)
        .getBody();
  }
}
