package com.musicplay.security;

import org.springframework.security.core.context.SecurityContextHolder;

public class SecurityUtil {

  public static Long getCurrentUserId() {
    Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    if (principal instanceof MusicPlayPrincipal) {
      return ((MusicPlayPrincipal) principal).getUserId();
    }
    return null;
  }

  public static String getCurrentUsername() {
    Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    if (principal instanceof MusicPlayPrincipal) {
      return ((MusicPlayPrincipal) principal).getUsername();
    }
    return null;
  }
}
