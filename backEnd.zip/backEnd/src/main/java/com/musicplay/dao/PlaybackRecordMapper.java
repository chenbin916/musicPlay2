package com.musicplay.dao;

import com.musicplay.domain.PlaybackRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PlaybackRecordMapper {
  int insert(PlaybackRecord playbackRecord);
  List<PlaybackRecord> selectRecentByUserId(@Param("userId") Long userId,
                                             @Param("limit") int limit);
}
