package com.musicplay.dao;

import com.musicplay.domain.Track;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TrackMapper {
  Track selectById(Long id);
  Track selectByFilePath(@Param("filePath") String filePath);
  Track selectByAudioUrl(@Param("audioUrl") String audioUrl);
  List<Track> selectPageByQuery(@Param("keyword") String keyword,
                                 @Param("artistId") Long artistId,
                                 @Param("albumId") Long albumId,
                                 @Param("offset") Long offset,
                                 @Param("limit") Long limit);
  Long selectCountByQuery(@Param("keyword") String keyword,
                          @Param("artistId") Long artistId,
                          @Param("albumId") Long albumId);
  List<Track> selectByFolderId(@Param("folderId") Long folderId);
  int insert(Track track);
  int deleteById(@Param("id") Long id);
}
