package com.musicplay.dao;

import com.musicplay.domain.Artist;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ArtistMapper {
  Artist selectById(Long id);
  List<Artist> selectByIds(List<Long> ids);
}
