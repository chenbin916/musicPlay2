package com.musicplay.dao;

import com.musicplay.domain.Album;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface AlbumMapper {
  Album selectById(Long id);
  List<Album> selectByIds(List<Long> ids);
}
