package com.musicplay.dao;

import com.musicplay.domain.Playlist;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PlaylistMapper {
  Playlist selectByIdAndUserId(@Param("id") Long id, @Param("userId") Long userId);
  List<Playlist> selectByUserIdAndQuery(@Param("userId") Long userId,
                                         @Param("type") String type);
  int insert(Playlist playlist);
  int update(Playlist playlist);
  int deleteByIdAndUserId(@Param("id") Long id, @Param("userId") Long userId);
  Long selectTrackCount(@Param("playlistId") Long playlistId);
}
