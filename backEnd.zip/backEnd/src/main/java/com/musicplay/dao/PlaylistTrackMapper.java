package com.musicplay.dao;

import com.musicplay.domain.PlaylistTrack;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PlaylistTrackMapper {
  List<PlaylistTrack> selectByPlaylistId(@Param("playlistId") Long playlistId);
  int insert(PlaylistTrack playlistTrack);
  int deleteByPlaylistAndTrack(@Param("playlistId") Long playlistId,
                                 @Param("trackId") Long trackId);
  int deleteByPlaylistId(@Param("playlistId") Long playlistId);
  Integer selectMaxOrderIndex(@Param("playlistId") Long playlistId);
}
