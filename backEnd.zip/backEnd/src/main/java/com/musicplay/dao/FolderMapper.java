package com.musicplay.dao;

import com.musicplay.domain.Folder;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface FolderMapper {
  Folder selectById(Long id);
  List<Folder> selectAll();
  Long selectTrackCount(@Param("folderId") Long folderId);
}
