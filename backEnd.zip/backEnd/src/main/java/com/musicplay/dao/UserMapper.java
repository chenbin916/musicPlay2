package com.musicplay.dao;

import com.musicplay.domain.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {
  User selectByUsername(String username);
  User selectById(Long id);
  int insert(User user);
}
