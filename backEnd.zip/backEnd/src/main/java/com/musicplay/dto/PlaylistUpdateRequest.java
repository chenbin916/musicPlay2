package com.musicplay.dto;

import lombok.Data;

@Data
public class PlaylistUpdateRequest {
  private String name;
  private String description;
}
