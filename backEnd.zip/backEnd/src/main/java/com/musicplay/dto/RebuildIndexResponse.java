package com.musicplay.dto;

import lombok.Data;

@Data
public class RebuildIndexResponse {
  private String message;
}
