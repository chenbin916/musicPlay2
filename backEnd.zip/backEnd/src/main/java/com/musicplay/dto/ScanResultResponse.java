package com.musicplay.dto;

import lombok.Data;

@Data
public class ScanResultResponse {
  private String message;
  private int count;
}
