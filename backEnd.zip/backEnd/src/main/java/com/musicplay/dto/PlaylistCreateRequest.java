package com.musicplay.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class PlaylistCreateRequest {
  @NotBlank(message = "歌单名称不能为空")
  private String name;

  private String description;
}
