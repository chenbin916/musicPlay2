package com.musicplay.dto;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class PlaybackRecordRequest {
  @NotNull(message = "歌曲ID不能为空")
  private Long trackId;

  private Integer position;

  private Integer duration;
}
