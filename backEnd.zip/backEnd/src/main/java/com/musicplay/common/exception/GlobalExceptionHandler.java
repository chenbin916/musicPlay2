package com.musicplay.common.exception;

import com.musicplay.common.result.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

  @ExceptionHandler(BizException.class)
  public Result<?> handleBizException(BizException e) {
    log.warn("Business exception: {}", e.getMessage());
    return Result.error(e.getCode(), e.getMessage());
  }

  @ExceptionHandler(Exception.class)
  public Result<?> handleException(Exception e) {
    log.error("System exception", e);
    return Result.error("系统错误");
  }
}
