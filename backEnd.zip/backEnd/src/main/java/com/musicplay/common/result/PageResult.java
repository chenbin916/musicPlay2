package com.musicplay.common.result;

import lombok.Data;
import java.util.List;

@Data
public class PageResult<T> {
  private List<T> records;
  private Long total;
  private Long current;
  private Long size;

  public PageResult(List<T> records, Long total, Long current, Long size) {
    this.records = records;
    this.total = total;
    this.current = current;
    this.size = size;
  }

  public static <T> PageResult<T> of(List<T> records, Long total, Long current, Long size) {
    return new PageResult<>(records, total, current, size);
  }
}
